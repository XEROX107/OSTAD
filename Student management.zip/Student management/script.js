let students = [];

const form = document.getElementById("studentForm");
const table = document.getElementById("studentTable");

form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = document.getElementById("name").value;
    const age = document.getElementById("age").value;
    const grade = document.getElementById("grade").value;
    const index = document.getElementById("studentIndex").value;

    if (index === "") {
        students.push({ name, age, grade });
    } else {
        students[index] = { name, age, grade };
        document.getElementById("studentIndex").value = "";
    }

    form.reset();
    displayStudents();
});

function displayStudents() {
    table.innerHTML = "";

    students.forEach((student, index) => {
        table.innerHTML += `
            <tr>
                <td>${student.name}</td>
                <td>${student.age}</td>
                <td>${student.grade}</td>
                <td>
                    <button class="edit" onclick="editStudent(${index})">Edit</button>
                    <button class="delete" onclick="deleteStudent(${index})">Delete</button>
                </td>
            </tr>
        `;
    });
}

function editStudent(index) {
    document.getElementById("name").value = students[index].name;
    document.getElementById("age").value = students[index].age;
    document.getElementById("grade").value = students[index].grade;
    document.getElementById("studentIndex").value = index;
}

function deleteStudent(index) {
    students.splice(index, 1);
    displayStudents();
}