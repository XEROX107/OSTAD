<?php

define("PI", 3.1416);
define("APP_NAME", "PHP Basics Test");

$num1 = 20;
$num2 = 5;


$addition = $num1 + $num2;
$subtraction = $num1 - $num2;
$multiplication = $num1 * $num2;
$division = $num1 / $num2;

printf("Application Name: %s\n", APP_NAME);
printf("Addition Result: %d\n", $addition);
printf("Subtraction Result: %d\n", $subtraction);
printf("Multiplication Result: %d\n", $multiplication);
printf("Division Result: %.2f\n", $division);

if ($num1 > $num2) {
    echo "$num1 is greater than $num2\n";
} else {
    echo "$num2 is greater than $num1\n";
}


$result = ($addition % 2 == 0) ? "Even" : "Odd";
echo "Sum of numbers is: $result\n";
