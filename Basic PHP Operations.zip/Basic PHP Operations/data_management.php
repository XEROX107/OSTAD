<?php

$fruits = array("Apple", "Banana", "Orange");

foreach ($fruits as $fruit) {
    echo $fruit . "\n";
}

$file = fopen("fruits.txt", "w");

foreach ($fruits as $fruit) {
    fwrite($file, $fruit . "\n");
}

fclose($file);

$file = fopen("fruits.txt", "r");

while (!feof($file)) {
    echo fgets($file);
}

fclose($file);
