<?php

function addNumbers($a, $b) {
    return $a + $b;
}

function checkEven($num) {
    if ($num % 2 == 0) {
        return "Even";
    } else {
        return "Odd";
    }
}
$sum = addNumbers(10, 5);

echo "Sum: $sum\n";
echo "Sum is: " . checkEven($sum) . "\n";

?>
